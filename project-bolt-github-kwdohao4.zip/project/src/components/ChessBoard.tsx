import React from 'react';
import { Square } from './Square';
import { GameStatus } from './GameStatus';
import { GameInfo } from './GameInfo';
import { useChessGame } from '../hooks/useChessGame';
import { Crown, RotateCcw } from 'lucide-react';

export const ChessBoard = () => {
  const {
    board,
    selectedPiece,
    currentPlayer,
    isGameOver,
    winner,
    inCheck,
    capturedPieces,
    moves,
    isComputerThinking,
    handleSquareClick,
    resetGame,
  } = useChessGame();

  return (
    <div className="min-h-screen w-full bg-[#FF90E8] flex items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-3xl">
        <div className="mb-8 text-center">
          <h1 className="text-4xl sm:text-6xl font-bold text-black mb-2">
            <span className="inline-flex items-center gap-3">
              <Crown className="w-8 h-8 sm:w-12 sm:h-12" />
              KNIGHTS.CX
            </span>
          </h1>
          <div className="inline-block bg-[#FFF500] neu-border-sm px-4 py-1 text-sm sm:text-base">
            BATTLE AGAINST THE COMPUTER!
          </div>
        </div>

        <div className="bg-[#CBF078] neu-border p-4 sm:p-8 flex flex-col gap-6">
          {/* Game Status */}
          <GameStatus
            isGameOver={isGameOver}
            winner={winner}
            inCheck={inCheck}
            currentPlayer={currentPlayer}
            isComputerThinking={isComputerThinking}
          />

          {/* Chess Board */}
          <div className="neu-border bg-white">
            <div className="grid grid-cols-8 gap-0 p-2">
              {board.map((row, i) =>
                row.map((piece, j) => (
                  <Square
                    key={`${i}-${j}`}
                    piece={piece}
                    position={{ row: i, col: j }}
                    isSelected={
                      selectedPiece?.position.row === i &&
                      selectedPiece?.position.col === j
                    }
                    isInCheck={piece?.type === 'king' && piece.color === inCheck}
                    onClick={() => handleSquareClick(i, j)}
                    isLight={(i + j) % 2 === 0}
                  />
                ))
              )}
            </div>
          </div>

          {/* Game Info (Captured Pieces and Move History) */}
          <GameInfo capturedPieces={capturedPieces} moves={moves} />

          <button
            onClick={resetGame}
            className="w-full bg-[#FF0000] text-white neu-border-sm hover:translate-y-0.5 hover:translate-x-0.5 active:translate-y-1 active:translate-x-1 transition-transform py-3 px-4 font-bold text-lg flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-6 h-6" />
            NEW GAME
          </button>
        </div>
      </div>
    </div>
  );
};