import React from 'react';
import { CapturedPieces } from './CapturedPieces';
import { MoveHistory } from './MoveHistory';
import { Piece, Move } from '../types';

interface GameInfoProps {
  capturedPieces: {
    white: Piece[];
    black: Piece[];
  };
  moves: Move[];
}

export const GameInfo: React.FC<GameInfoProps> = ({ capturedPieces, moves }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-4">
        <CapturedPieces pieces={capturedPieces.white} color="white" />
        <CapturedPieces pieces={capturedPieces.black} color="black" />
      </div>
      <MoveHistory moves={moves} />
    </div>
  );
};