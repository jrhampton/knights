import React from 'react';
import { Swords, AlertTriangle, Bot } from 'lucide-react';

interface GameStatusProps {
  isGameOver: boolean;
  winner: string | null;
  inCheck: 'white' | 'black' | null;
  currentPlayer: 'white' | 'black';
  isComputerThinking: boolean;
}

export const GameStatus: React.FC<GameStatusProps> = ({
  isGameOver,
  winner,
  inCheck,
  currentPlayer,
  isComputerThinking,
}) => {
  return (
    <div className="bg-white neu-border-sm p-3 text-center">
      {isGameOver ? (
        <p className="font-bold flex items-center gap-2 justify-center">
          <Swords className="w-5 h-5" />
          {winner.toUpperCase()} WINS!
        </p>
      ) : inCheck ? (
        <p className="font-bold flex items-center gap-2 justify-center text-[#FF0000]">
          <AlertTriangle className="w-5 h-5" />
          {inCheck.toUpperCase()} IS IN CHECK!
        </p>
      ) : (
        <p className="font-bold flex items-center gap-2 justify-center">
          {currentPlayer === 'black' ? (
            <>
              <Bot className="w-5 h-5 animate-bounce" />
              {isComputerThinking ? "THINKING..." : "COMPUTER'S TURN"}
            </>
          ) : (
            <>
              <span className="w-3 h-3 bg-black" />
              YOUR TURN
            </>
          )}
        </p>
      )}
    </div>
  );
};