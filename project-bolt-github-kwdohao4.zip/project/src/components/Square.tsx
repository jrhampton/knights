import React from 'react';
import { Piece } from '../types';

interface SquareProps {
  piece: Piece | null;
  position: { row: number; col: number };
  isSelected: boolean;
  isLight: boolean;
  isInCheck?: boolean;
  onClick: () => void;
}

export const Square: React.FC<SquareProps> = ({
  piece,
  isSelected,
  isLight,
  isInCheck,
  onClick,
}) => {
  const getPieceSymbol = (piece: Piece | null) => {
    if (!piece) return null;
    const symbols: { [key: string]: string } = {
      'white-pawn': '♙',
      'white-rook': '♖',
      'white-knight': '♘',
      'white-bishop': '♗',
      'white-queen': '♕',
      'white-king': '♔',
      'black-pawn': '♟',
      'black-rook': '♜',
      'black-knight': '♞',
      'black-bishop': '♝',
      'black-queen': '♛',
      'black-king': '♚',
    };
    return symbols[`${piece.color}-${piece.type}`];
  };

  return (
    <div
      onClick={onClick}
      className={`
        aspect-square
        flex items-center justify-center text-3xl sm:text-4xl
        transition-all duration-200 cursor-pointer relative
        ${isLight ? 'bg-[#F3F3F3]' : 'bg-[#23B5D3]'}
        ${isSelected ? 'ring-[3px] ring-black' : ''}
        ${isInCheck ? 'ring-[3px] ring-[#FF0000]' : ''}
        hover:brightness-95
        group
      `}
    >
      {piece && (
        <span 
          className={`
            select-none transform transition-transform relative z-10
            ${piece.color === 'white' ? 'text-white' : 'text-black'}
            ${isSelected ? 'scale-110' : 'scale-100'}
            hover:scale-105
          `}
          style={{
            textShadow: piece.color === 'white' ? '1px 1px 0px rgba(0,0,0,0.8)' : 'none'
          }}
        >
          {getPieceSymbol(piece)}
        </span>
      )}
    </div>
  );
};