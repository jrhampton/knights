import React from 'react';
import { Move } from '../types';
import { ScrollText } from 'lucide-react';

interface MoveHistoryProps {
  moves: Move[];
}

export const MoveHistory: React.FC<MoveHistoryProps> = ({ moves }) => {
  return (
    <div className="bg-white neu-border-sm p-4">
      <h3 className="text-black font-bold mb-2 uppercase flex items-center gap-2 text-sm">
        <ScrollText className="w-4 h-4" />
        Move History
      </h3>
      <div className="max-h-[200px] overflow-y-auto custom-scrollbar">
        {moves.length === 0 ? (
          <p className="text-gray-500 text-sm">No moves yet</p>
        ) : (
          <div className="space-y-1">
            {Array.from({ length: Math.ceil(moves.length / 2) }).map((_, i) => (
              <div
                key={i}
                className="grid grid-cols-[auto_1fr_1fr] gap-2 text-sm items-center"
              >
                <span className="font-mono">{i + 1}.</span>
                <span className="font-bold">{moves[i * 2]?.notation}</span>
                <span className="text-gray-700">
                  {moves[i * 2 + 1]?.notation || ''}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};