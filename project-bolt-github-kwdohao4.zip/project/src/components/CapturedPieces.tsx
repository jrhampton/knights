import React from 'react';
import { Piece } from '../types';

interface CapturedPiecesProps {
  pieces: Piece[];
  color: 'white' | 'black';
}

export const CapturedPieces: React.FC<CapturedPiecesProps> = ({ pieces, color }) => {
  const getPieceSymbol = (piece: Piece): string => {
    const symbols: Record<string, string> = {
      'white-pawn': '♙',
      'white-rook': '♖',
      'white-knight': '♘',
      'white-bishop': '♗',
      'white-queen': '♕',
      'white-king': '♔',
      'black-pawn': '♟',
      'black-rook': '♜',
      'black-knight': '♞',
      'black-bishop': '♝',
      'black-queen': '♛',
      'black-king': '♚',
    };
    return symbols[`${piece.color}-${piece.type}`] || '';
  };

  return (
    <div className="bg-white neu-border-sm p-4">
      <h3 className="text-black font-bold mb-2 uppercase text-sm">
        Captured {color} pieces
      </h3>
      <div className="flex flex-wrap gap-1">
        {pieces.length === 0 ? (
          <p className="text-gray-500 text-sm">None yet</p>
        ) : (
          pieces.map((piece, index) => (
            <span
              key={index}
              className={`text-2xl ${
                piece.color === 'white'
                  ? 'text-gray-700'
                  : 'text-black'
              }`}
            >
              {getPieceSymbol(piece)}
            </span>
          ))
        )}
      </div>
    </div>
  );
};