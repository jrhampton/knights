import { useState, useCallback, useEffect } from 'react';
import { Piece, Position, Move } from '../types';
import { initialBoard, isValidMove, movePiece, isInCheck } from '../utils/chess';
import { getMoveNotation } from '../utils/notation';
import { findBestMove } from '../utils/ai';

export const useChessGame = () => {
  const [board, setBoard] = useState<(Piece | null)[][]>(initialBoard());
  const [selectedPiece, setSelectedPiece] = useState<{
    piece: Piece;
    position: Position;
  } | null>(null);
  const [currentPlayer, setCurrentPlayer] = useState<'white' | 'black'>('white');
  const [isGameOver, setIsGameOver] = useState(false);
  const [winner, setWinner] = useState<string | null>(null);
  const [inCheck, setInCheck] = useState<'white' | 'black' | null>(null);
  const [capturedPieces, setCapturedPieces] = useState<{
    white: Piece[];
    black: Piece[];
  }>({ white: [], black: [] });
  const [moves, setMoves] = useState<Move[]>([]);
  const [isComputerThinking, setIsComputerThinking] = useState(false);

  const makeMove = useCallback(
    (from: Position, to: Position) => {
      const piece = board[from.row][from.col];
      const targetPiece = board[to.row][to.col];
      
      if (!piece) return false;

      const newBoard = movePiece(board, from, to);
      const nextPlayer = currentPlayer === 'white' ? 'black' : 'white';
      const willBeInCheck = isInCheck(newBoard, nextPlayer);

      const moveNotation = getMoveNotation(
        piece,
        from,
        to,
        targetPiece || undefined,
        willBeInCheck
      );

      const move: Move = {
        piece,
        from,
        to,
        notation: moveNotation,
        captured: targetPiece || undefined,
      };

      if (targetPiece) {
        setCapturedPieces(prev => ({
          ...prev,
          [currentPlayer]: [...prev[currentPlayer], targetPiece]
        }));
      }

      setBoard(newBoard);
      setMoves(prev => [...prev, move]);
      
      if (targetPiece?.type === 'king') {
        setIsGameOver(true);
        setWinner(currentPlayer);
      } else {
        if (willBeInCheck) {
          setInCheck(nextPlayer);
        } else {
          setInCheck(null);
        }
        setCurrentPlayer(nextPlayer);
      }

      return true;
    },
    [board, currentPlayer]
  );

  const handleSquareClick = useCallback(
    (row: number, col: number) => {
      if (isGameOver || currentPlayer === 'black') return;

      const clickedPiece = board[row][col];

      if (!selectedPiece && clickedPiece?.color === currentPlayer) {
        setSelectedPiece({
          piece: clickedPiece,
          position: { row, col },
        });
        return;
      }

      if (selectedPiece) {
        if (row === selectedPiece.position.row && col === selectedPiece.position.col) {
          setSelectedPiece(null);
          return;
        }

        if (isValidMove(board, selectedPiece.position, { row, col }, selectedPiece.piece)) {
          const simulatedBoard = movePiece(board, selectedPiece.position, { row, col });
          if (isInCheck(simulatedBoard, currentPlayer)) {
            setSelectedPiece(null);
            return;
          }

          makeMove(selectedPiece.position, { row, col });
          setSelectedPiece(null);
        } else {
          if (clickedPiece?.color === currentPlayer) {
            setSelectedPiece({
              piece: clickedPiece,
              position: { row, col },
            });
          } else {
            setSelectedPiece(null);
          }
        }
      }
    },
    [board, currentPlayer, selectedPiece, isGameOver, makeMove]
  );

  // Computer move logic
  useEffect(() => {
    if (currentPlayer === 'black' && !isGameOver) {
      setIsComputerThinking(true);
      // Add a small delay to make the computer's moves feel more natural
      const timeoutId = setTimeout(() => {
        const bestMove = findBestMove(board, 'black');
        if (bestMove) {
          makeMove(bestMove.from, bestMove.to);
        }
        setIsComputerThinking(false);
      }, 500);

      return () => clearTimeout(timeoutId);
    }
  }, [currentPlayer, board, isGameOver, makeMove]);

  const resetGame = useCallback(() => {
    setBoard(initialBoard());
    setSelectedPiece(null);
    setCurrentPlayer('white');
    setIsGameOver(false);
    setWinner(null);
    setInCheck(null);
    setCapturedPieces({ white: [], black: [] });
    setMoves([]);
    setIsComputerThinking(false);
  }, []);

  return {
    board,
    selectedPiece,
    currentPlayer,
    isGameOver,
    winner,
    inCheck,
    capturedPieces,
    moves,
    isComputerThinking,
    handleSquareClick,
    resetGame,
  };
};