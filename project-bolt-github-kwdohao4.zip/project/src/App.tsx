import React from 'react';
import { ChessBoard } from './components/ChessBoard';

function App() {
  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center p-4">
      <ChessBoard />
    </div>
  );
}

export default App;