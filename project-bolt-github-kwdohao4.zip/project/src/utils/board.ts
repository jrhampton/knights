import { Piece, PieceColor } from '../types';

export const createInitialBoard = (): (Piece | null)[][] => {
  const board: (Piece | null)[][] = Array(8).fill(null).map(() => Array(8).fill(null));

  // Set up pawns as knights
  for (let i = 0; i < 8; i++) {
    board[1][i] = { type: 'knight', color: 'black' };
    board[6][i] = { type: 'knight', color: 'white' };
  }

  // Set up back row
  const setupRow = (row: number, color: PieceColor) => {
    const pieces: Piece['type'][] = [
      'knight', 'knight', 'knight', 'queen', 'king', 'knight', 'knight', 'knight'
    ];
    pieces.forEach((type, col) => {
      board[row][col] = { type, color };
    });
  };

  setupRow(0, 'black');
  setupRow(7, 'white');

  return board;
};