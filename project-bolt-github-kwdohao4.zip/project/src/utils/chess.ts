import { Piece, Position, PieceColor } from '../types';
import { createInitialBoard } from './board';

export const initialBoard = createInitialBoard;

export const isValidPosition = (pos: Position): boolean => {
  return pos.row >= 0 && pos.row < 8 && pos.col >= 0 && pos.col < 8;
};

export const findKing = (board: (Piece | null)[][], color: PieceColor): Position | null => {
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece?.type === 'king' && piece.color === color) {
        return { row, col };
      }
    }
  }
  return null;
};

export const isInCheck = (board: (Piece | null)[][], color: PieceColor): boolean => {
  const kingPosition = findKing(board, color);
  if (!kingPosition) return false;

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece && piece.color !== color) {
        const from: Position = { row, col };
        if (isValidMove(board, from, kingPosition, piece)) {
          return true;
        }
      }
    }
  }
  return false;
};

export const isValidMove = (
  board: (Piece | null)[][],
  from: Position,
  to: Position,
  piece: Piece
): boolean => {
  if (!isValidPosition(from) || !isValidPosition(to)) return false;
  
  const targetPiece = board[to.row][to.col];
  if (targetPiece?.color === piece.color) return false;

  const rowDiff = Math.abs(to.row - from.row);
  const colDiff = Math.abs(to.col - from.col);

  switch (piece.type) {
    case 'knight':
      return (rowDiff === 2 && colDiff === 1) || (rowDiff === 1 && colDiff === 2);

    case 'queen':
      // Check path obstruction for queen
      const rowStep = rowDiff === 0 ? 0 : (to.row - from.row) / rowDiff;
      const colStep = colDiff === 0 ? 0 : (to.col - from.col) / colDiff;
      
      let currentRow = from.row + rowStep;
      let currentCol = from.col + colStep;

      while (currentRow !== to.row || currentCol !== to.col) {
        if (board[currentRow][currentCol] !== null) return false;
        currentRow += rowStep;
        currentCol += colStep;
      }
      return from.row === to.row || from.col === to.col || rowDiff === colDiff;

    case 'king':
      return rowDiff <= 1 && colDiff <= 1;

    default:
      return false;
  }
};

export const movePiece = (
  board: (Piece | null)[][],
  from: Position,
  to: Position
): (Piece | null)[][] => {
  if (!isValidPosition(from) || !isValidPosition(to)) {
    return board;
  }

  const newBoard = board.map(row => [...row]);
  newBoard[to.row][to.col] = newBoard[from.row][from.col];
  newBoard[from.row][from.col] = null;
  return newBoard;
};