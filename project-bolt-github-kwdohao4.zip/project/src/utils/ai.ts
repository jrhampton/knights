import { Piece, Position, PieceColor } from '../types';
import { isValidMove, movePiece, isInCheck } from './chess';

interface Move {
  from: Position;
  to: Position;
  score: number;
}

// Piece values for evaluation
const pieceValues = {
  knight: 3,
  queen: 9,
  king: 100,
};

// Position evaluation bonus for center control
const positionValues = [
  [1, 1, 1, 1, 1, 1, 1, 1],
  [1, 2, 2, 2, 2, 2, 2, 1],
  [1, 2, 3, 3, 3, 3, 2, 1],
  [1, 2, 3, 4, 4, 3, 2, 1],
  [1, 2, 3, 4, 4, 3, 2, 1],
  [1, 2, 3, 3, 3, 3, 2, 1],
  [1, 2, 2, 2, 2, 2, 2, 1],
  [1, 1, 1, 1, 1, 1, 1, 1],
];

// Evaluate board position
const evaluateBoard = (board: (Piece | null)[][], color: PieceColor): number => {
  let score = 0;

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece) {
        const pieceScore = pieceValues[piece.type] * positionValues[row][col];
        score += piece.color === color ? pieceScore : -pieceScore;
      }
    }
  }

  return score;
};

// Get all valid moves for a piece
const getValidMoves = (
  board: (Piece | null)[][],
  from: Position,
  piece: Piece
): Position[] => {
  const moves: Position[] = [];

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const to = { row, col };
      if (isValidMove(board, from, to, piece)) {
        moves.push(to);
      }
    }
  }

  return moves;
};

// Get all possible moves for a color
const getAllMoves = (
  board: (Piece | null)[][],
  color: PieceColor
): Move[] => {
  const moves: Move[] = [];

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = board[row][col];
      if (piece && piece.color === color) {
        const from = { row, col };
        const validMoves = getValidMoves(board, from, piece);

        validMoves.forEach(to => {
          const newBoard = movePiece(board, from, to);
          const score = evaluateBoard(newBoard, color);
          moves.push({ from, to, score });
        });
      }
    }
  }

  return moves;
};

export const findBestMove = (
  board: (Piece | null)[][],
  color: PieceColor
): { from: Position; to: Position } | null => {
  const moves = getAllMoves(board, color);
  
  if (moves.length === 0) return null;

  // Filter out moves that would put us in check
  const safeMoves = moves.filter(move => {
    const newBoard = movePiece(board, move.from, move.to);
    return !isInCheck(newBoard, color);
  });

  if (safeMoves.length === 0) return null;

  // Sort moves by score and add some randomness to make the AI less predictable
  safeMoves.sort((a, b) => {
    const randomFactor = Math.random() * 0.2 - 0.1; // ±10% randomness
    return (b.score + randomFactor) - (a.score + randomFactor);
  });

  return {
    from: safeMoves[0].from,
    to: safeMoves[0].to,
  };
};